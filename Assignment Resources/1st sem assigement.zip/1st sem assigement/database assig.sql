create database TU
use TU

create table Customer (CutomerId int primary key, FName char(20),LName varchar(20),DateOfBirth date,Address varchar(50),Email varchar(50))

insert into Customer values (1, 'Ram','sharma','1/2/1992', 'jorpati', 'sharma@gmail.com')
insert into Customer values (2, 'Hari','sherpa','5/6/1996', 'chabil', 'hari123@gmail.com')
insert into Customer values (3, 'rabi','shyam','8/7/1995', 'buddha', 'rabishyam1@gmail.com')
insert into Customer values (4, 'kabita','lamichhane','3/5/1998', 'mulpani', 'klami1234@gmail.com')
insert into Customer values (5, 'depesh','KC','9/8/1994', 'thali', 'deepkc@gmail.com')
sp_tables 
select * from Customer

create table Supplier (SupplierId int primary key, SupplierName varchar(50),email varchar(50))

insert into Supplier values (1,'Ekta Publication' , 'ekta@gmail.com')
insert into Supplier values (2,'Goodwill Publication' , 'Goodwill@gmail.com')
insert into Supplier values (3,'Devkota Publication' , 'devkota@gmail.com')
insert into Supplier values (4,'sangam Publication' , 'sangam@gmail.com')
insert into Supplier values (5,'srijana Publication' , 'srijana@gmail.com')

select * from Supplier
drop table BookDetail

create table Staff (StaffId int primary key, StaffName varchar(50), 
StaffAddress varchar(50), MobileNo varchar(20),Email varchar(50),MemberType varchar(50),
Staffstatus varchar(20), Department varchar(20)) 


select * from Staff
drop table Staff

insert into Staff values (1,'vsal', 'Mulpani','9749400079','bsal@gmail.com','Temporary','Officer', 'Electronics')
insert into Staff values (2,'kabir', 'Battisputali','9749400213','kabir123@gmail.com','Parmanent','Developer', 'Mechanical')
insert into Staff values (3,'Samikshya', 'Samakhusi','974932112244','samikshya@gmail.com','part time','UI Design', 'Art')
insert into Staff values (4,'Kris', 'Maitidevi','9749407879','kris123@gmail.com','casul',' Developer', 'Computers')
insert into Staff values (5,'Vee', 'Swayambu','9749122379','vidushi23@gmail.com','Temporary','manager', 'Electrical')

create table BookDetail (BookCode int primary key, BookName varchar(50), Tag
varchar(20), Title varchar(50), ISBN int, Publisher varchar(50),Writer varchar(50),
StaffId int, PublishedDate Date, Categories varchar(50),qty int, price money, foreign key (StaffId) references Staff(StaffId))


insert into BookDetail values (1,'C Programming', 'programming','C progamming', 1,'Ekta Publication', 'vsal',1, '1/3/1991', 'coding', 20, 700 )
insert into BookDetail values (2,'Database', 'database','DBMS',2,'Ekta Publication', 'Saugat',2, '1/4/1991', 'DBMS', 25, 650 )
insert into BookDetail values (3,'System Analysis', 'Design','System Design',3,'Ekta Publication', 'Samikshya',3, '1/2/1991', 'System', 12, 600 )
insert into BookDetail values (4,'Mathematics For Computing', 'Mathematics','Introduction to Mathematics',4,'Ekta Publication', 'Vee',4, '4/2/1991', 'Maths', 12, 700 )
insert into BookDetail values (5,'Communication Technique', 'programming','C progamming',5,'Ekta Publication', 'Bishal',5, '1/2/1992', 'coding', 10, 455 )

select * from BookDetail
drop table bookdetail

create table Purchase (TransId int primary key, TransDate date, BookCode int,
SupplierId int, PaidAmmount money, StaffId int, foreign key (StaffId) references Staff(StaffId), 
foreign key (SupplierId) references Supplier(SupplierId),foreign key (BookCode) references BookDetail(BookCode))
insert into purchase values(1, '10/11/1994', 1, 1, 550, 001)
 insert into purchase values(2, '11/11/1992', 2, 2, 600, 002)
 insert into purchase values(3, '12/13/2001', 3, 3, 555, 001)
  insert into purchase values(4, '10/11/1995', 4, 5, 1000, 003)
  insert into purchase values(5, '5/15/1884', 5, 5, 2000,004)

  select *from purchase


create table Sales (TransId int primary key , TransDate date,BookCode int,CutomerId int,
PaidAmmount money, StaffId int, Quantity int, foreign key (StaffId) references Staff(StaffId), 
foreign key (BookCode) references BookDetail(BookCode),
foreign key (CutomerId) references Customer(CutomerId) )
insert into sales values(1, '1/3/1991', 1, 1, 700,001,2)
insert into sales values(2, '1/1/1991', 2, 2, 600, 001,2)
insert into sales values(3, '10/1/2001', 3, 3, 555, 002,3)
insert into sales values(4, '10/11/1990', 4, 4, 1000, 003, 2)
insert into sales values(5, '12/15/1992', 5, 5, 1500, 004, 3)

select *from sales

create table OrderBook(Order_Id int primary key, BookCode int, CustomerId int, OrderDate Date,
foreign key (BookCode) references Bookdetail(BookCode), foreign key (CustomerId) references Customer(CutomerId))
insert into OrderBook values(1, 1, 001, '9/10/1991')
insert into OrderBook values(2, 2, 002, '9/10/2002')
insert into OrderBook values(3, 3, 001, '9/08/1994')
insert into OrderBook values(4, 5, 003, '9/10/1993')
insert into OrderBook values(5, 5, 005, '01/11/1992')
select *from OrderBook


create table Rating (BookCode int primary key, CustomerId int, RatingStar int, 
foreign key (BookCode) references BookDetail(BookCode),
foreign key (CustomerId) references Customer(CutomerId))
insert into Rating values(1, 1, 5)
insert into Rating values(2, 2, 4)
insert into Rating values(3, 3, 4)
insert into Rating values(4, 5, 3)
insert into Rating values(5, 5, 3)

select *from Rating

create table Feedback (BookCode int primary key, CustomerId int, Feedback varchar(100),
foreign key (BookCode) references BookDetail(BookCode),
foreign key (CustomerId) references Customer (CutomerId))
insert into Feedback values(1,1,'Good')
insert into Feedback values(2,2,'Amazing')
insert into Feedback values(3,3,'Good')
insert into Feedback values(4,4,'Average')
insert into Feedback values(5,5,'Amazing')
select *from Feedback


create table OrderBookPublisher(StaffId int primary key, BookCode int, SupplierId int, OrderDate date, 
foreign key (StaffId) references Staff(StaffId), 
foreign key (BookCode) references BookDetail(BookCode),
foreign key (SupplierId) references Supplier(SupplierId))
insert into OrderBookPublisher values(1,1,1,'9/5/1994')
insert into OrderBookPublisher values(2,2,2,'7/8/1995')
insert into OrderBookPublisher values(3,3,3,'6/9/1996')
insert into OrderBookPublisher values(4,4,4,'7/15/1993')
insert into OrderBookPublisher values(5,5,5,'8/3/1998')
insert into OrderBookPublisher values(6,6,6,'9/4/1997')

select *from OrderBookPublisher
sp_tables

1.
select top 5 * from BookDetail order by PublishedDate desc
select top 5 * from BookDetail order by PublishedDate asc
2)
select StaffId, Month(orderdate) AS monthly, Supplier.supplierId,Supplier.SupplierName,BookCode from Orderbookpublisher
inner join Supplier on Supplier.SupplierId=OrderBookPublisher.StaffId 
where staffId=(SELECT StaffId from Staff 
where Staffstatus='Developer')

3)
select TransId as InvoiceNumber,TransDate as InvoiceDate,SupplierId,sum(PaidAmmount) as TotalPaid from Purchase
group by TransId,TransDate,SupplierId

4)
select * from Customer
select CutomerId as IdentificationNumber, Fname,LName,Address from Customer

5)
select Customer.CutomerId as indentificationNUmber,Fname,Lname,Address,BookDetail.BookCode as
BookSerialNumber,BookName,Quantity,Sales.TransDate as
DeliveryDate from Sales inner join Customer on Sales.CutomerId=Customer.CutomerId
inner join BookDetail on BookDetail.BookCode=Sales.BookCode

6)
select Categories,BookCode,BookName,qty as Quantity from BookDetail order by qty
7)
select Categories,sum(BookCode) as 'Total Number of Books' from BookDetail group by Categories
8)
select count (BookCode), sum(Price) from BookDetail
9)
select BookCode,CustomerId,
case when Feedback='' then 'Terrible'
when Feedback='Great' then 'Masterpiece'
else Feedback end as 'Feedback'
from Feedback
