#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <conio.h>
#include <unistd.h>
#include <time.h>
#include <stdio.h>

#define MAX_CANDIDATES 100
#define MAX_VOTERS 1000
#define MAX_STR_LEN 100

#define ADMIN_USERNAME "admin"
#define ADMIN_PASSWORD "admin123"

#define VOTER_USERNAME "user"
#define VOTER_PASSWORD "password"


// Struct for holding election schedule information
typedef struct {
char constituency[50];
int date;
} ElectionSchedule;
ElectionSchedule schedule[4];

// Struct for holding candidate information
typedef struct {
int id;
char name[50];
char party[50];
char constituency[50];
int voteCount;
} Candidate;
Candidate candidates[MAX_CANDIDATES];

typedef struct {
	int voteNum;
	int canId;
} VoteCount;

// Struct for holding voter information
typedef struct {
int id,voteCount;
char name[50];
char dob[50];
char address[50];
char password[50];
} Voter;
Voter voters[MAX_VOTERS];

// Function prototypes
void createElectionSchedule();
void login();
void voterLogin();
void registerCandidate();
void updateCandidate();
void addCandidate();
void deleteCandidate();
void listCandidates();
void registerVoter();
void updateVoter();
void deleteVoter();
void searchVoter();
void castVote();
void showVoteResults();
void saveVotersToFile();
void loadVoters();
void readVotersFromFile();

int main() {
createElectionSchedule();

int choice;

bool loggedIn = false;
bool voterLoggedIn=false;
char username[50], password[50];
int user;
callback:
	system("CLS");
printf("\n1) Admin\n");
printf("2) Voter register\n");
printf("3) Caste vote\n");
printf("4) Exit");
printf("\nSelect Login Pannel ");
scanf("%d",&user);
switch(user)
{
	case 1:
		login();
		loggedIn=true;
		break;
	case 2:
	 	registerVoter();
		break;
	case 3:
		castVote();
		break;
	case 4:
		return 0;
		break;
}

while (loggedIn) {
	system("CLS");
	createElectionSchedule();
  printf("\nElection Management System\n");
  printf("1. Register candidate\n");
  printf("2. Update candidate\n");
  printf("3. Delete candidate\n");
  printf("4. List candidates\n");
  printf("5. update voter\n");
  printf("6. delete Voter\n");
  printf("7. Search voter\n");
  printf("8. Show vote results\n");
  printf("9.Logout \n");
  printf("Enter your choice: ");
  scanf("%d", &choice);

  switch (choice) {
    case 1:
      registerCandidate();
      break;
    case 2:
      updateCandidate();
      break;
    case 3:
      deleteCandidate();
      break;
    case 4:
      listCandidates();
      break;
    
	case 5:
       updateVoter();
		break;
	
	case 6:
		deleteVoter();
		break;
	case 7:
		searchVoter();
		break;
	case 8:
		showVoteResults();
		break;
	case 9:
		loggedIn = false;
		goto callback;	
		break;	
	default:
		printf("Invalid choice\n");
		break;
}
}
}

// Function to create the election schedule
void createElectionSchedule() {
	int i;
// Initialize the election schedule
strcpy(schedule[0].constituency, "Kathmandu");
schedule[0].date = 20220909;
strcpy(schedule[1].constituency, "Gorkha");
schedule[1].date = 20220909;
strcpy(schedule[2].constituency, "Chitwan");
schedule[2].date = 20220909;
strcpy(schedule[3].constituency, "Pokhara");
schedule[3].date = 20220909;
    printf("Election Schedule Table:\n");
    printf("+----------------+---------------------+\n");
    printf("| Constituency   | Date of Election     |\n");
    printf("+----------------+---------------------+\n");
    for ( i = 0; i < 4; i++)
    {
        // Extract year, month, and day from the date integer
        int year = schedule[i].date / 10000;
        int month = (schedule[i].date / 100) % 100;
        int day = schedule[i].date % 100;
        
        // Print the formatted date string
        printf("| %-15s | %04d/%02d/%02d           |\n", schedule[i].constituency, year, month, day);
    }
    printf("+----------------+---------------------+\n");

    // Save the schedule to file
    FILE* fp = fopen("schedule.txt", "w");
    if (fp == NULL) {
        printf("Error opening schedule.txt file\n");
        return;
    }
    fprintf(fp, "Constituency\tDate of Election (yyyy/mm/dd)\n");
    for(i=0; i<4; i++)
    {
        // Extract year, month, and day from the date integer
        int year = schedule[i].date / 10000;
        int month = (schedule[i].date / 100) % 100;
        int day = schedule[i].date % 100;
        
        // Write the formatted date string to file
        fprintf(fp, "%s\t%04d/%02d/%02d\n", schedule[i].constituency, year, month, day);
    }
    fclose(fp);
}


// Function to login to the system
void login() {
char username[50], password[50];
bishal:
printf("Enter username: ");
scanf("%s", username);
printf("Enter password: ");
scanf("%s", password);

if (strcmp(username, ADMIN_USERNAME) == 0 && strcmp(password, ADMIN_PASSWORD) == 0) {
printf("Login successful\n");
sleep(1);
} else {
printf("Invalid username or password\n");
sleep(1);
goto bishal;
}
}
void voterLogin() {
char username[50], password[50];
bishal1:
printf("Enter username: ");
scanf("%s", username);
printf("Enter password: ");
scanf("%s", password);

if (strcmp(username, VOTER_USERNAME) == 0 && strcmp(password, VOTER_PASSWORD) == 0) {
printf("Login successful\n");
sleep(1);
} else {
printf("Invalid username or password\n");
sleep(1);
goto bishal1;
}
}


void registerCandidate() {
    Candidate candidate = { 0 };
    printf("Enter candidate name: ");
    scanf("%s", candidate.name);
    printf("Enter candidate party: ");
    scanf("%s", candidate.party);
    printf("Enter candidate constituency: ");
    scanf("%s", candidate.constituency);

    // Find the next available candidate ID
    FILE* fp = fopen("candidate.txt", "a+");
    if (fp == NULL) {
        printf("Error opening candidate.txt file\n");
        sleep(1);
        return;
    }
    int maxId = 0;
    int candidateId;
    char name[MAX_STR_LEN], party[MAX_STR_LEN], constituency[MAX_STR_LEN];
    while (fscanf(fp, "%d\t%99[^\t]\t%99[^\t]\t%99[^\n]\n", &candidateId, name, party, constituency) == 4) {
        if (candidateId > maxId) {
            maxId = candidateId;
        }
    }
    if (maxId >= MAX_CANDIDATES) {
        printf("The maximum number of candidates has been reached.\n");
        fclose(fp);
        return;
    }
    candidate.id = maxId + 1;

    // Write candidate data to file
    fprintf(fp, "%d\t%s\t%s\t%s\n", candidate.id, candidate.name, candidate.party, candidate.constituency);
    fclose(fp);

    printf("Candidate registered successfully\n");
    sleep(1);
}



void updateCandidate() {
    int id;
    int j;
    printf("Enter candidate ID: ");
    if (scanf("%d", &id) != 1) {
        printf("Error: invalid input\n");
        return;
    }

    FILE* fp = fopen("candidate.txt", "r");
    if (fp == NULL) {
        printf("Error opening candidate.txt file\n");
        return;
    }

    int found = 0;
    Candidate candidates[MAX_CANDIDATES];
    int i = 0;
    while (fscanf(fp, "%d\t%99[^\t]\t%99[^\t]\t%99[^\n]\n", &candidates[i].id, candidates[i].name, candidates[i].party, candidates[i].constituency) == 4) {
        if (candidates[i].id == id) {
            found = 1;
            printf("Enter new candidate name: ");
            if (scanf("%99s", candidates[i].name) != 1) {
                printf("Error: invalid input\n");
                fclose(fp);
                return;
            }
            printf("Enter new candidate party: ");
            if (scanf("%99s", candidates[i].party) != 1) {
                printf("Error: invalid input\n");
                fclose(fp);
                return;
            }
            printf("Enter new candidate constituency: ");
            if (scanf("%99s", candidates[i].constituency) != 1) {
                printf("Error: invalid input\n");
                fclose(fp);
                return;
            }
        }
        i++;
    }
    fclose(fp);

    if (!found) {
        printf("Candidate with ID %d not found.\n", id);
        return;
    }

    fp = fopen("candidate.txt", "w");
    if (fp == NULL) {
        printf("Error opening candidate.txt file\n");
        return;
    }
    for ( j = 0; j < i; j++) {
        fprintf(fp, "%d\t%s\t%s\t%s\n", candidates[j].id, candidates[j].name, candidates[j].party, candidates[j].constituency);
    }
    fclose(fp);

    printf("Candidate with ID %d updated successfully\n", id);
}

void deleteCandidate() {
    int id;
    printf("Enter candidate ID: ");
    scanf("%d", &id);

    // Load candidates from file into memory
    FILE* fp = fopen("candidate.txt", "r");
    if (fp == NULL) {
        printf("Error opening candidate.txt file\n");
        exit(EXIT_FAILURE);
    }

    int numCandidates = 0;
    char line[MAX_STR_LEN];
    while (fgets(line, MAX_STR_LEN, fp) != NULL) {
        numCandidates++;
    }

    Candidate* candidates = (Candidate*) malloc(numCandidates * sizeof(Candidate));
    if (candidates == NULL) {
        printf("Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }

    fseek(fp, 0, SEEK_SET);
    int i = 0;
    while (fgets(line, MAX_STR_LEN, fp) != NULL) {
        if (sscanf(line, "%d\t%s\t%s\t%s", &candidates[i].id, candidates[i].name, candidates[i].party, candidates[i].constituency) != 4) {
            printf("Error parsing candidate data\n");
            exit(EXIT_FAILURE);
        }
        i++;
    }

    fclose(fp);

    // Find candidate with specified ID
    bool candidateFound = false;
    for (i = 0; i < numCandidates; i++) {
        if (candidates[i].id == id) {
            candidateFound = true;
            candidates[i].id = -1;
            strcpy(candidates[i].name, "");
            strcpy(candidates[i].party, "");
            strcpy(candidates[i].constituency, "");
            break;
        }
    }

    if (!candidateFound) {
        printf("Candidate not found\n");
        exit(EXIT_FAILURE);
    }

    // Save updated candidates back to file
    fp = fopen("candidate.txt", "w");
    if (fp == NULL) {
        printf("Error opening candidate.txt file\n");
        exit(EXIT_FAILURE);
    }

    for (i = 0; i < numCandidates; i++) {
        if (candidates[i].id != -1) {
            fprintf(fp, "%d\t%s\t%s\t%s\n", candidates[i].id, candidates[i].name, candidates[i].party, candidates[i].constituency);
        }
    }

    fclose(fp);

    free(candidates);

    printf("Candidate deleted successfully\n");
}
void listCandidates() {
	int i,j;
    printf("ID\tName\t\tParty\t\tConstituency\n");

    // Read all candidates from file into an array
    Candidate candidates[MAX_CANDIDATES] = {0};
    int numCandidates = 0;
    FILE* fp = fopen("candidate.txt", "r");
    if (fp == NULL) {
        printf("Error opening candidate.txt file\n");
        return;
    }
    while (numCandidates < MAX_CANDIDATES && fscanf(fp, "%d\t%s\t%s\t%s\n", &candidates[numCandidates].id, candidates[numCandidates].name, candidates[numCandidates].party, candidates[numCandidates].constituency) == 4) {
        numCandidates++;
    }
    fclose(fp);

    // Sort the array by candidate IDs
    for ( i = 0; i < numCandidates - 1; i++) {
        for ( j = i + 1; j < numCandidates; j++) {
            if (candidates[i].id > candidates[j].id) {
                Candidate temp = candidates[i];
                candidates[i] = candidates[j];
                candidates[j] = temp;
            }
        }
    }
    
    // Display the sorted array
    for (i = 0; i < numCandidates; i++) {
        if (candidates[i].id != 0) {
            printf("%d\t%s\t\t%s\t\t%s\n", candidates[i].id, candidates[i].name, candidates[i].party, candidates[i].constituency);
        }
    }
    printf("Press any key to continue...\n");
    getch();
}


// Function to register a voter
void registerVoter() {
    int age;
    Voter voter;
    FILE *fp;
    fp = fopen("voters.txt", "a+");
    if (fp == NULL) {
        printf("Error opening file\n");
        sleep(1);
        return;
    }

    // Get the maximum voter ID by reading the contents of the file
    int sno = 0;
    char line[100];
    while (fgets(line, sizeof(line), fp) != NULL) {
        sno++;
    }
    fclose(fp);

    // Increment voter ID for the new voter
    fp = fopen("voters.txt", "a");
    if (fp == NULL) {
        printf("Error opening file\n");
        sleep(1);
        return;
    }
    voter.id = sno + 1;

    printf("Enter voter name: ");
    scanf("%s", voter.name);

    printf("Enter date of birth in AD (yyyy/mm/dd): ");
    scanf("%s", voter.dob);
    getchar(); // consume newline character

    // Calculate age from date of birth
    time_t current_time;
    struct tm *time_info;
    char year[5], month[3], day[3];
    time(&current_time);
    time_info = localtime(&current_time);
    strftime(year, 5, "%Y", time_info);
    strftime(month, 3, "%m", time_info);
    strftime(day, 3, "%d", time_info);
    int currentYear = atoi(year);
    int birthYear = atoi(strtok(voter.dob, "/"));
    int birthMonth = atoi(strtok(NULL, "/"));
    int birthDay = atoi(strtok(NULL, "/"));
    age = currentYear - birthYear;
    if (birthMonth > atoi(month) || (birthMonth == atoi(month) && birthDay > atoi(day))) {
        age--;
    }

    // Check if the voter is eligible to vote (age >= 18)
    if (age < 18) {
        printf("Voter is not eligible to vote.\n");
        sleep(1);
        fclose(fp);
        return;
    }

    printf("Enter voter address (max 50 characters): ");
    fgets(voter.address, 50, stdin);
    voter.address[strcspn(voter.address, "\n")] = '\0'; // remove newline character

    printf("Enter voter password (max 50 characters): ");
    fgets(voter.password, 50, stdin);
    voter.password[strcspn(voter.password, "\n")] = '\0'; // remove newline character

    // Store the voter information in the file
    fprintf(fp, "%d\t%-20s\t%-20s\t%-10s\t%-50s\t%s\n", voter.id, voter.name, voter.name, voter.dob, voter.address, voter.password);
    fclose(fp);

    // Print the voter's details in a table
    printf("+------+--------------------+----------------------+-------------+----------------------------------------------------+------------------+\n");
    printf("| SNO  |     VOTER ID        |         Name         | Date of Birth|                       Address                        |      Password    |\n");
    printf("+------+--------------------+----------------------+-------------+----------------------------------------------------+------------------+\n");
    printf("|%-6d|%-20d|%-20s|%-13s|%-50s|%18s|\n", voter.id, voter.id, voter.name, voter.dob, voter.address, "*****");
    printf("+------+--------------------+----------------------+-------------+----------------------------------------------------+------------------+\n");

// Display a success message
printf("\nVoter registration successful.\n");
printf("Voter ID: %d\n", voter.id);
printf("Please remember your voter ID and password for future use.\n");
sleep(2);
}



void updateVoter() {
    int id, found = 0;
    printf("Enter voter id to update: ");
    scanf("%d", &id);

    // Open input file for reading
    FILE *fp = fopen("voters.txt", "r");
    if (fp == NULL) {
        printf("Error opening input file\n");
        return;
    }

    // Open temporary file for writing
    FILE *temp = fopen("temp.txt", "w");
    if (temp == NULL) {
        printf("Error creating temporary file\n");
        fclose(fp);
        return;
    }

    Voter voter;
    int count;
    while ((count = fscanf(fp, "%d\t%[^\t]\t%[^\t]\t%[^\t]\t%[^\n]\n", &voter.id, voter.name, voter.dob, voter.address, voter.password)) == 5) {
        if (voter.id == id) {
            found = 1;
            printf("Enter new name: ");
            scanf("%s", voter.name);
            if (strlen(voter.name) > 50) {
                printf("Error: name is too long (max 50 characters)\n");
                fclose(fp);
                fclose(temp);
                remove("temp.txt");
                return;
            }
            printf("Enter new date of birth (yyyy/mm/dd): ");
            scanf("%s", voter.dob);
            if (strlen(voter.dob) != 10 || voter.dob[4] != '/' || voter.dob[7] != '/') {
                printf("Error: date of birth has an invalid format (yyyy/mm/dd)\n");
                fclose(fp);
                fclose(temp);
                remove("temp.txt");
                return;
            }
            getchar(); // consume newline character
            printf("Enter new address (max 50 characters): ");
            fgets(voter.address, sizeof(voter.address), stdin);
            voter.address[strcspn(voter.address, "\n")] = '\0'; // remove newline character
            if (strlen(voter.address) > 50) {
                printf("Error: address is too long (max 50 characters)\n");
                fclose(fp);
                fclose(temp);
                remove("temp.txt");
                return;
            }
            printf("Enter new password (max 50 characters): ");
            fgets(voter.password, sizeof(voter.password), stdin);
            voter.password[strcspn(voter.password, "\n")] = '\0'; // remove newline character
            if (strlen(voter.password) > 50) {
                printf("Error: password is too long (max 50 characters)\n");
                fclose(fp);
                fclose(temp);
                remove("temp.txt");
                return;
            }
        }
        fprintf(temp, "%d\t%s\t%s\t%s\t%s\n", voter.id, voter.name, voter.dob, voter.address, voter.password);
    }

    if (!found) {
        printf("Error: voter with id %d not found\n", id);
        fclose(fp);
        fclose(temp);
        remove("temp.txt");
        return;
    }

    fclose(fp);
    fclose(temp);

    // Replace the input file with the temporary file
    remove("voters.txt");
    rename("temp.txt", "voters.txt");

    printf("Voter with id %d updated successfully.\n", id);
}


void deleteVoter() {
    int id, found = 0;
    char confirm;
    printf("Enter voter id to delete: ");
    scanf("%d", &id);

    // Open input file for reading
    FILE *fp = fopen("voters.txt", "r");
    if (fp == NULL) {
        printf("Error opening file\n");
        sleep(1);
        return;
    }

    // Open temporary file for writing
    FILE *temp = fopen("temp.txt", "w");
    if (temp == NULL) {
        printf("Error creating temporary file\n");
        sleep(1);
        fclose(fp);
        return;
    }

    Voter voter;
    while (fscanf(fp, "%d\t%[^\t]\t%[^\t]\t%[^\t]\t%s\n", &voter.id, voter.name, voter.dob, voter.address, voter.password) != EOF) {
        if (voter.id == id) {
            found = 1;
            printf("Are you sure you want to delete the voter with ID %d? (y/n): ", id);
            scanf(" %c", &confirm);
            if (confirm == 'n') {
                fprintf(temp, "%d\t%s\t%s\t%s\t%s\n", voter.id, voter.name, voter.dob, voter.address, voter.password);
            } else if (confirm == 'y') {
                printf("Deleting voter with ID %d...\n", id);
                continue; // Skip writing this voter to the temporary file
            } else {
                printf("Invalid input. Please enter y or n.\n");
                fprintf(temp, "%d\t%s\t%s\t%s\t%s\n", voter.id, voter.name, voter.dob, voter.address, voter.password);
            }
        } else {
            fprintf(temp, "%d\t%s\t%s\t%s\t%s\n", voter.id, voter.name, voter.dob, voter.address, voter.password);
        }
    }
    fclose(fp);
    fclose(temp);

    if (!found) {
        printf("Voter with ID %d not found.\n", id);
        remove("temp.txt");
        return;
    }

    // Delete original file and rename temporary file to original file
    if (remove("voters.txt") == 0 && rename("temp.txt", "voters.txt") == 0) {
        printf("Voter with ID %d deleted successfully.\n", id);
    } else {
        printf("Error deleting voter.\n");
    }
}

void searchVoter() {
    int id, found = 0;
    printf("Enter voter ID to search: ");
    scanf("%d", &id);

    // Open input file for reading
    FILE *fp = fopen("voters.txt", "r");
    if (fp == NULL) {
        printf("Error opening input file\n");
        return;
    }

    Voter voter;
    int count;
    while ((count = fscanf(fp, "%d\t%[^\t]\t%[^\t]\t%[^\t]\t%[^\n]\n", &voter.id, voter.name, voter.dob, voter.address, voter.password)) == 5) {
        if (voter.id == id) {
            found = 1;
             // Print the voter's details in a table
    printf("+------+--------------------+----------------------+-------------+----------------------------------------------------+------------------+\n");
    printf("| SNO  |     VOTER ID        |         Name         | Date of Birth|                       Address                        |      Password    |\n");
    printf("+------+--------------------+----------------------+-------------+----------------------------------------------------+------------------+\n");
    printf("|%-6d|%-20d|%-20s|%-13s|%-50s|%18s|\n", voter.id, voter.id, voter.name, voter.dob, voter.address, "*****");
    printf("+------+--------------------+----------------------+-------------+----------------------------------------------------+------------------+\n");
            break;
        }
    }

    fclose(fp);

    if (!found) {
        printf("Voter with ID %d not found.\n", id);
    }
    getch();
}

void castVote() {
    int id;
    printf("Enter voter id: ");
    scanf("%d", &id);

    // Open input file for reading
    FILE *fp = fopen("voters.txt", "r");
    if (fp == NULL) {
        printf("Error opening input file\n");
        return;
    }

    Voter voter;
    int found = 0;
    while (fscanf(fp, "%d\t%[^\t]\t%[^\t]\t%[^\t]\t%s\n", &voter.id, voter.name, voter.dob, voter.address, voter.password) == 5) {
        if (voter.id == id) {
            found = 1;

            // Check if the voter has already cast a vote
            char vote_file_name[50];
            sprintf(vote_file_name, "%d_vote.txt", id);
            FILE *vote_fp = fopen(vote_file_name, "r");
            if (vote_fp != NULL) {
                printf("This voter has already cast a vote\n");
                fclose(vote_fp);
                fclose(fp);
                return;
            }

            // Display candidate list
            printf("Candidate list:\n");
            FILE *candidate_fp = fopen("candidate.txt", "a+");
            if (candidate_fp == NULL) {
                printf("Error opening candidate list file\n");
                fclose(fp);
                return;
            }

            Candidate candidate;
            int votecon = 0; // initialize vote count to 0
            while (fscanf(candidate_fp, "%d\t%[^\t]\t%[^\t]\t%[^\n]\n", &candidate.id, candidate.name, candidate.party, candidate.constituency) == 4) {
                printf("%d\t%s\t%s\t%s\n", candidate.id, candidate.name, candidate.party, candidate.constituency);
            }
            fclose(candidate_fp);

            // Get candidate ID from user
            int candidate_id;
            printf("Enter candidate ID: ");
            scanf("%d", &candidate_id);

            // Open vote file for appending
            FILE *vote_out_fp = fopen("votes.txt", "a");
            if (vote_out_fp == NULL) {
                printf("Error opening vote file\n");
                fclose(fp);
                return;
            }

            // Write vote to file and update vote count
            fprintf(vote_out_fp, "%d\t%d\t%d\n", id, candidate_id, ++votecon);

            // Close vote file
            fclose(vote_out_fp);

            // Create vote file to prevent voter from casting vote again
            vote_fp = fopen(vote_file_name, "w");
            fclose(vote_fp);

            printf("Vote cast successfully\n");
        }
    }

    // Close input file
    fclose(fp);

    if (!found) {
        printf("Voter not found\n");
    }
}


// Function to read candidate information from file
void readCandidatesFromFile() {
    FILE *fp = fopen("candidates.txt", "r");
    if (fp == NULL) {
        printf("Error opening candidates.txt file\n");
        exit(1);
    }
    int count = 0;
    while (count < MAX_CANDIDATES && fscanf(fp, "%d\t%[^\t]\t%[^\t]\t%[^\n]\n", &candidates[count].id, candidates[count].name, candidates[count].party, candidates[count].constituency) == 4) {
        count++;
    }
    fclose(fp);
}

void showVoteResults() {
    // Read all candidates from file into an array
    Candidate candidates[MAX_CANDIDATES] = {0};
    int numCandidates = 0;
    int i;
    FILE* fp = fopen("candidate.txt", "r");
    if (fp == NULL) {
        printf("Error opening candidate.txt file\n");
        exit(1);
    }
    while (numCandidates < MAX_CANDIDATES && fscanf(fp, "%d\t%[^\t]\t%[^\t]\t%[^\n]\n", &candidates[numCandidates].id, candidates[numCandidates].name, candidates[numCandidates].party, candidates[numCandidates].constituency) == 4) {
        candidates[numCandidates].voteCount = 0;
        numCandidates++;
    }
    fclose(fp);

    // Read all votes from file and update the vote count for each candidate
    FILE* fq = fopen("votes.txt", "r");
    if (fq == NULL) {
        printf("Error opening votes.txt file\n");
        exit(1);
    }
    int voterId, candidateId, votecon;
    while (fscanf(fq, "%d\t%d\t%d\n", &voterId, &candidateId, &votecon) == 3) {
        // Find the candidate with the given ID in the array
        int candidateIndex = -1;
        for ( i = 0; i < numCandidates; i++) {
            if (candidates[i].id == candidateId) {
                candidateIndex = i;
                break;
            }
        }
        if (candidateIndex != -1) {
            candidates[candidateIndex].voteCount++;
        }
    }
    fclose(fq);

    // Display the results
    printf("ID\tName\t\tParty\t\tConstituency\t\tVoteCount\n");
    for ( i = 0; i < numCandidates; i++) {
        printf("%d\t%s\t\t%s\t\t%s\t\t\t%d\n", candidates[i].id, candidates[i].name, candidates[i].party, candidates[i].constituency, candidates[i].voteCount);
    }

    // Find the winner
    int highestVoteCount = 0;
    int winnerIndex = -1;
    for (i = 0; i < numCandidates; i++) {
        if (candidates[i].voteCount > highestVoteCount) {
            highestVoteCount = candidates[i].voteCount;
            winnerIndex = i;
        }
    }
    if (winnerIndex != -1) {
        printf("\nThe winner is %s from %s with %d votes\n", candidates[winnerIndex].name, candidates[winnerIndex].constituency, candidates[winnerIndex].voteCount);
    }

    getch();
}

