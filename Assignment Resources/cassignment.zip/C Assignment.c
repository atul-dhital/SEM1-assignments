#include<conio.h> 
#include<stdlib.h> 
#include<time.h> 
#include<stdio.h>
#include<math.h>    
#include<string.h>  

void main()
{
	int z;
	while(1)
	{
	system("CLS");
	printf("\t\t\t\t\tWelcome to Democratic Election\t\t\t\t\n\n\n");
	printf("\n\n How do you want to proceed?\n\n\n");
	printf("1) By Creating the Schedule of the Election (access restricted to Admininstrator only)\n\n");
	printf("2) By Modifying the list of the Candidates of the Election (access restricted to Administrator only)\n\n");
	printf("3) Through Voter Registration\n\n");
	printf("4) By Updating the details of the Voter \n\n");
	printf("5) By Searching for the details of Voter \n\n");
	printf("6) By Casting the Vote\n\n");
	printf("7) By Displaying the Schedule of the Election \n\n");
	printf("8) By Displaying the List of all the Candidates \n\n");
	printf("9) By Displaying the Result of the Election \n\n");
	printf("10) Exit \n");
	printf("\nEnter Your choice \n");
	scanf("%d",&z);
	printf("\n\n");
	switch(z)
	{
		case 1:
			schedule_of_election();     
			break;

		case 2:
            list_of_candidate();
			break;

		case 3:
			append_elector();
			break;

		case 4:
			change_elector();
			break;

		case 5:
        	search_elector();
			break;

		case 6:
        	give_vote();
			break;

        case 7:
			display_election_schedule();
            break;

        case 8:
			display_candidate();
        	break;

		case 9:
			outcome();
			break;
			
		case 10:
			break;

		default:
		printf("Wrong Data\n");
	}
	if(z==10)
	{
		break;
	}
    }
}


struct list_of_candidate
{
	char fullname[40];
	char nameofparty[40];
	int serialnumber;
	char campaigning[40];
}participant[1200];


struct count_of_vote
{
	char firstnameofvoter[25];
	char lastnameofvoter[25];
	int serialnumber;
	char candidate[15];
	char nameofparty[40];
	char campaigning[40];
}calculate[110];


struct list_of_voter
{
	char firstname[25],lastname[25];
	char address[35];
	char date_of_birth[25];
	int serialnumber;
	char password[25];	
}elector[1100];


struct ballot
{
	char a[75];
	int thedate;
}horizontal[99];

void schedule_of_election();
void display_election_schedule();
void list_of_candidate();
void append_candidate();
void amend_candidate();
void remove_candidate();
void display_candidate();
void append_elector();
void change_elector();
void update_elector();
void search_elector();
void remove_elector();
void amend_password();
void give_vote();
void outcome();

void schedule_of_election()
{
	system("CLS");
	int x,y;
	char p[75],q[75],r[75]="rixen",s[50]="rixen123";
	retry:
	printf("Input Administrator Username \n");
	scanf("%s",p);
	printf("Input Administrator Passcode \n");
	scanf("%s",q);
	if(strcmp(p,"rixen")==0 && strcmp(q,"rixen123")==0)
	{
		system("CLS");
		printf("\nAdministrator Login Success!!\n");
		FILE *g;
		int j,k=0,l;
		g=fopen("schedule.txt","w");
		fprintf(g, " ------- --------------------- ---------------------------- \n");
		fprintf(g,"|%-7s|%-22s|%-28s|\n","S.N.","Constituency","Date(YYYYMMDD)");
		fprintf(g, " ------- --------------------- ---------------------------- \n");
	    printf("Input Information for the Schedule of the Election\n");
		while(1)
		{
			printf("\n Input Constituency:\n");
			scanf("%s",&horizontal[k].a);
			printf("Input Election Date in Format(YYYYMMDD):\n");
			scanf("%ld",&horizontal[k].thedate);
			fprintf(g,"|%-6d|%-21s|%-27ld|\n",k+1,horizontal[k].a,horizontal[k].thedate);
			printf("\nInput 1 if you wish to add more schedule or Input 0 to stop creating schedules\n");
			scanf("%d",&l);
			if(l==0)
			{
				break;
			}
			k=k+1;
			j=k;
		}
		fprintf(g, " ----- -------------------- -------------------------- \n");
		fclose(g);
		system("CLS");
		printf("Your data has been saved in the text file as shown here:\n\n\n");
		char horizontal[100];
	    g=fopen("schedule.txt","r");
	    while(fgets(horizontal,sizeof(horizontal),g))
	    {
		printf("%s",horizontal);
	    }
	    fclose(g);
	    }
	    else
	    {
		printf("Invalid Administrator Username or Passcode\nYou may retry\n");
		goto retry;
	    }
	    getch();
}
void display_election_schedule()
{
	system("CLS");
	char horizontal[110];
	FILE *g;
	g=fopen("schedule.txt","r");
	while(fgets(horizontal,sizeof(horizontal),g))
	{
		printf("%s",horizontal);
	}
	fclose(g);
	getch();
}
void list_of_candidate()
{
	system("CLS");
	int x,y;
	char p[70],q[70],r[70]="rixen",s[50]="rixen123";
	try_again:
	printf("Input Administrator Username \n");
	scanf("%s",p);  
	printf("Input Administrator Passcode \n");
	scanf("%s",q);
	if(strcmp(p,"rixen")==0 && strcmp(q,"rixen123")==0)
	{
		printf("\nAdministrator Verification Successful!!!\n");
		int r;
		while(1)
		{
		system("CLS");
		printf("How do you want to proceed?\n\n");
		printf("1) Register/Add a New Candidate\n");
		printf("2) Modify an Existing Candidate\n");
		printf("3) Remove an Existing Candidate\n");
		printf("4) Display All Candidates\n");
		printf("5) Leave\n");
		printf("\nEnter your choice\t");
		scanf("%d",&r);
		switch(r)
		{
			case 1:
				append_candidate();         
				break;

			case 2:
				amend_candidate();
				break;

			case 3:
				remove_candidate();
				break;

			case 4:
				display_candidate();
				break;

			case 5:
				break;

			default:
		    printf("Wrong Data\n");
		}
		if(r==5)
		{
			break;
		}
	    }
	}
	else
	{
		printf("\nInvalid Administrator Username or Passcode\nYou may retry\n\n");
		goto try_again;
	}
}
void append_candidate()
{
	system("CLS");
    FILE *gd;
    int a,b=0,c=0,d=0;
    char path[150];
    again:
    gd=fopen("candidatelist.txt","r");
	if(gd == NULL)
	{
	gd=fopen("candidatelist.txt","w");
	fprintf(gd,"---- -------------- -------------- -------------- \n");
	fprintf(gd,"%-4s|%-14s|%-14s|%-14s|","Serial","Candidate's'","Party's'","Running");
	fprintf(gd,"%-4s|%-14s|%-14s|%-14s|","Number","Name","Name","From");
	fprintf(gd,"---- -------------- -------------- -------------- \n");
	fclose(gd);
	goto again;
    }
    while(fgets(path, sizeof(path),gd))
    {
    d++;
    }
    fclose(gd);
    b=d-4;
    gd=fopen("candidatelist.txt","a");
    while(1)
    {
        printf("\nInput Full Name of the Candidate:\n");
		scanf("%s",participant[b].fullname);
		printf("Input Political Affiliation/Party of the Candidate:\n");
		scanf("%s",participant[b].nameofparty);
	    printf("Where is the Candidate running the election from?\n");
		scanf("%s",participant[b].campaigning);
		fprintf(gd,"%-5d%-15s%-15s%-15s\n",b+1,participant[b].fullname,participant[b].nameofparty,participant[b].campaigning);
		b=b+1;
        printf("\nInput 1 for addition of another row or 0 to halt\t");
        scanf("%d",&a);
        if(a==0)
        {
        	break;
		}
	}
	fclose(gd);
	printf("\n\nInformation Storage Success!\n\n");
    getch();
}
void amend_candidate()
{
	system("CLS");
	int serialnumber,c=1,d=1;
	char path[150];
	FILE *gd;
	gd=fopen("candidatelist.txt","r");
	while(fgets(path, sizeof(path),gd))
    {
    	printf("%s",path);
        c++;
    }
    fclose(gd);
    printf("\n\nInput the Serial Number of the Candidate\n");
    scanf("%d",&serialnumber);
    printf("\nInput Candidate's FullName\n");
    scanf("%s",participant[serialnumber].fullname);
    printf("\nInput Political Affiliation/Party\n");
    scanf("%s",participant[serialnumber].nameofparty);
    printf("\nWhere is the candidate running from?\n");
    scanf("%s",participant[serialnumber].campaigning);
    FILE *gu;
    int cal,H=0;
    char a1,a2;
    gd=fopen("candidatelist.txt","r");
    gu=fopen("temp.txt","w");
    while(fgets(path,sizeof(path),gd))
    {
    if(d==serialnumber+4)
    {
    fprintf(gu,"%-6d%-16s%-16s%-16s\n",serialnumber,participant[serialnumber].fullname,participant[serialnumber].nameofparty,participant[serialnumber].campaigning);
	}
	else
	{
		fputs(path,gu);
	}
	d++;
    }
    fclose(gd);
    fclose(gu);
    remove("candidatelist.txt");
    rename("temp.txt","candidatelist.txt");
    printf("\nThe Candidate has been successfully removed from the Election");
    getch();
}
void remove_candidate()
{
	system("CLS");
	int serialnumber,c=1,d=1,ok,b=1;
	char path[150],di;
	FILE *gd,*gu;
	gd=fopen("candidatelist.txt","r");
	while(fgets(path, sizeof(path),gd))
    {
    	printf("%s",path);
        c++;
    }
    fclose(gd);
    printf("\n\nInput the Serial Number of the Candidate for Deletion\n");
    scanf("%d",&serialnumber);
    serialnumber=serialnumber+4;
    gd=fopen("candidatelist.txt","r");
    gu=fopen("temp.txt","w");
    while(d<c)
    {
    if(d<5)
    {
    fgets(path,sizeof(path),gd);
		fputs(path,gu);
	}
	else if(d==serialnumber)
	{
		fgets(path,sizeof(path),gd);
		d++;
		continue;
	}
	else
	{
		fgets(path,sizeof(path),gd);
		memmove(path,path+4,strlen(path)-4+1); 
		fprintf(gu,"%-4d%s",b,path);
		b++;
	}
	d++;
    }
    fclose(gd);
    fclose(gu);
    remove("candidatelist.txt");
    rename("temp.txt","candidatelist.txt");
    printf("\nSuccessfully removed candidate!");
    getch();
}
void display_candidate()
{
	system("CLS");
	FILE *gd;
	int d=1;
	char path[150];
	again:
	gd=fopen("candidatelist.txt","r");
	if(gd == NULL)
	{
	gd=fopen("candidatelist.txt","w");
	fprintf(gd,"---- -------------- -------------- -------------- \n");
	fprintf(gd,"%-4s|%-14s|%-14s|%-14s|\n","Serial","Candidate's'","Political","Candidate Running");
	fprintf(gd,"%-4s|%-14s|%-14s|%-14s|\n","Number","Name","Party Name","From");
	fprintf(gd,"---- -------------- -------------- -------------- \n");
	fclose(gd);
	goto again;
    }
	while(fgets(path, sizeof(path),gd))
    {
    	printf("%s",path);
        d++;
    }
    fclose(gd);
    getch();
 }
 
 void append_elector()
 {
 	system("CLS");
 	int e,f=0,g,h,i,j;
 	char pq[6],jk[6],v[4]="/",vot[120];
 	FILE *gg;
 	voter:
 	gg=fopen("voterlist.txt","r");
 	if(gg==NULL)
 	{
 		gg=fopen("voterlist.txt","w");
 		fprintf(gg," ------------ -------------------------- --------------- --------------- ------------\n");
 		fprintf(gg,"|%-12s|%11s %-15s|%-15s|%-15s|%-12s|\n","Voter Serial Number","Voter","Name","DOB","Address","Passcode");
 		fprintf(gg," ----------- ------------------------ -------------- -------------- -----------\n");
 		fclose(gg);
 		goto voter;
	}
	srand(time(0));
	e=(rand()%1000)+1;
	gg=fopen("voterlist.txt","a");
	printf("Input your D.O.B in Bikram Sambat\n");
	printf("Input Year of Birth\t\t");
	scanf("%d",&h);
	printf("Input Month of Birth\t\t");
	scanf("%d",&i);
	printf("Input Day of Birth\t\t");
    scanf("%d",&j);
    g=2079-h;
	if(g>18)
	{
    sprintf(elector[f].date_of_birth,"%d",h);
    sprintf(pq,"%d",i);
    sprintf(jk,"%d",j);
    strcat(elector[f].date_of_birth,v);
    strcat(elector[f].date_of_birth,pq);
    strcat(elector[f].date_of_birth,v);
    strcat(elector[f].date_of_birth,jk);
	printf("Input the First Name:\t\t");
	scanf("%s",elector[f].firstname);
	printf("Input the Last Name:\t\t");
	scanf("%s",elector[f].lastname);
	printf("Input the Address:\t\t");
	scanf("%s",elector[f].address);
	printf("Create a unique passcode:\t\t");
	scanf("%s",elector[f].password);
	fprintf(gg,"%13d%11s %-16s%-16s%-16s%-12s\n",e,elector[f].firstname,elector[f].lastname,elector[f].date_of_birth,elector[f].address,elector[f].password);
	printf("\n\nYour unique identification number is:\t%d\n(IMPORTANT! Note down this number to cast vote or make modifications.)\n",e);
	f++;
    }
    else
    {
    	printf("You are not eligible to cast vote during this election!\n");
	}
    fclose(gg);
    printf("\nVoter/Elector Registration Successful!");
    getch();
 }
 void change_elector()
 {
 	system("CLS");
    int m;
    while(1)
    {
    system("CLS");
	printf("\nHow would you like to proceed?\n");
	printf("1) Update the details of the Elector/Voter \n");
	printf("2) Remove an existing voter\n");
	printf("3) Reset the Password for a Voter's account'\n");
	printf("4) Exit\n");
    printf("Input your decision\t");
    scanf("%d",&m);
    switch(m)
    {
    	case 1:
    		update_elector();
    		break;

    	case 2:
    		remove_elector();
    		break;

    	case 3:
    		update_elector();
    		break;

    	case 4:
    		break;

    	default:
		printf("Wrong Data\n");

	}
	if(m==4)
	{
		break;
	}
    }
 }
void update_elector()
{
	int serialnumber,d=0,e=1,f=0,h=0,i,j,k;
	char password[25],path[200],sm[4],sd[4],t[4]="/";
	system("CLS");
	printf("Enter unique identification number\t");
	scanf("%d",&serialnumber);
	printf("Input your unique passcode\t");
	scanf("%s",password);
	FILE *gg,*gu;
	gg=fopen("voterlist.txt","r");
	while(fgets(path,sizeof(path),gg))
	{
		f++;
	}
	fclose(gg);
	gg=fopen("voterlist.txt","r");
	gu=fopen("temp.txt","w");
	while(e<=f)
	{
		if(e<4)
		{
			fgets(path,sizeof(path),gg);
			fprintf(gu,"%s",path);
		}
		else
		{
			fscanf(gg,"%d%s%s%s%s%s",&elector[h].serialnumber,elector[h].firstname,elector[h].lastname,elector[h].date_of_birth,elector[h].address,elector[h].password);
			if(serialnumber==elector[h].serialnumber && strcmp(password,elector[h].password)==0)
			{
				printf("\nInput the New Details to be Updated\n\n");
				printf("Input the D.O.B in Bikram Sambat\n");
              	printf("Input the Birth Year\t\t");
	            scanf("%d",&i);
	            printf("Input the Birth Month\t\t");
	            scanf("%d",&j);
	            printf("Input Birth Day\t\t");
                scanf("%d",&k);
                sprintf(elector[h].date_of_birth,"%d",i);
                sprintf(sm,"%d",j);
                sprintf(sd,"%d",k);
                strcat(elector[h].date_of_birth,t);
                strcat(elector[h].date_of_birth,sm);
                strcat(elector[h].date_of_birth,t);
                strcat(elector[h].date_of_birth,sd);
	            printf("Input the First Name\t\t");
	            scanf("%s",elector[h].firstname);
	            printf("Input the Last Name\t\t");
	            scanf("%s",elector[h].lastname);
	            printf("Input the Address\t\t");
	            scanf("%s",elector[h].address);
	            fprintf(gu,"%13d%11s %-16s%-16s%-16s%-12s\n",serialnumber,elector[h].firstname,elector[h].lastname,elector[h].date_of_birth,elector[h].address,elector[h].password);
	            d=d+1;
			}
			else
			{
			    fprintf(gu,"%13d%11s %-16s%-16s%-16s%-12s\n",elector[h].serialnumber,elector[h].firstname,elector[h].lastname,elector[h].date_of_birth,elector[h].address,elector[h].password);
			}
			h++;
		}
		e++;
	}
	fclose(gg);
	fclose(gu);
	remove("voterlist.txt");
	rename("temp.txt","voterlist.txt");
	if(d=1)
	{
		printf("\nThe data is successfully updated!\n");
	}
	else
	{
		printf("\nThis voter cannot be identified. Enter correct unique identification number AND/OR Password");
	}
	getch();
}
void remove_elector()
{
	int serialnumber,d=0,e=1,f=0,h=0;
	char password[25],path[200];
	system("CLS");
	printf("Input your unique identification number\t");
	scanf("%d",&serialnumber);
	printf("Input your passcode\t");
	scanf("%s",password);
	FILE *gg,*gu;
	gg=fopen("voterlist.txt","r");
	while(fgets(path,sizeof(path),gg))
	{
		f++;
	}
	fclose(gg);
	gg=fopen("voterlist.txt","r");
	gu=fopen("temp.txt","w");
	while(e<f)
	{
		if(e<4)
		{
			fgets(path,sizeof(path),gg);
			fprintf(gu,"%s",path);
		}
		else
		{
			fscanf(gg,"%d%s%s%s%s%s",&elector[h].serialnumber,elector[h].firstname,elector[h].lastname,elector[h].date_of_birth,elector[h].address,elector[h].password);
			if(serialnumber==elector[h].serialnumber && strcmp(password,elector[h].password)==0)
			{
				h++;
				d=d+1;
				continue;
			}
			else
			{
			    fprintf(gu,"%13d%11s %-16s%-16s%-16s%-12s\n",elector[h].serialnumber,elector[h].firstname,elector[h].lastname,elector[h].date_of_birth,elector[h].address,elector[h].password);
			}
			h++;
		}
		e++;
	}
	fclose(gg);
	fclose(gu);
	remove("voterlist.txt");
	rename("temp.txt","voterlist.txt");
	if(d=1)
	{
		printf("\nVoter removed Successfully!\n");
	}
	else
	{
		printf("\nPlease input correct unique identification number AND/OR Password. Voter/Elector Not Found!");
	}
	getch();
}
void amend_password()
{
	int serialnumber,d=0,e=1,f=0,h=0;
	char password[25],path[200];
	system("CLS");
	printf("Input unique identification number\t");
	scanf("%d",&serialnumber);
	printf("Input the password\t");
	scanf("%s",password);
	FILE *gg,*gu;
	gg=fopen("voterlist.txt","r");
	while(fgets(path,sizeof(path),gg))
	{
		f++;
	}
	fclose(gg);
	gg=fopen("voterlist.txt","r");
	gu=fopen("temp.txt","w");
	while(e<=f)
	{
		if(e<4)
		{
			fgets(path,sizeof(path),gg);
			fprintf(gu,"%s",path);
		}
		else
		{
			fscanf(gg,"%d%s%s%s%s%s",&elector[h].serialnumber,elector[h].firstname,elector[h].lastname,elector[h].date_of_birth,elector[h].address,elector[h].password);
			if(serialnumber==elector[h].serialnumber && strcmp(password,elector[h].password)==0)
			{
				printf("Input a new and unique password:");
				scanf("%s",elector[h].password);
	            fprintf(gu,"%13d%11s %-16s%-16s%-16s%-12s\n",serialnumber,elector[h].firstname,elector[h].lastname,elector[h].date_of_birth,elector[h].address,elector[h].password);
	            d=d+1;
			}
			else
			{
			    fprintf(gu,"%13d%11s %-16s%-16s%-16s%-12s\n",elector[h].serialnumber,elector[h].firstname,elector[h].lastname,elector[h].date_of_birth,elector[h].address,elector[h].password);
			}
			h++;
		}
		e++;
	}
	if(d==1)
	{
		printf("\nYour password has been modified successfully\n");
	}
	else
	{
		printf("\nPlease enter correct unique identification number AND/OR Password. Could not find Voter!");
	}
	fclose(gg);
	fclose(gu);
	remove("voterlist.txt");
	rename("temp.txt","voterlist.txt");
	getch();
}
void search_elector()
{
    system("CLS");
	int serialnumber,e=1,f=0,h=0,y=0;
	char password[25],path[200];
	printf("Input unique identification number\t");
	scanf("%d",&serialnumber);
	printf("Input unique password\t");
	scanf("%s",password);
	FILE *gg;
	gg=fopen("voterlist.txt","r");
	while(fgets(path,sizeof(path),gg))
	{
		f++;
	}
	fclose(gg);
	gg=fopen("voterlist.txt","r");
	while(e<=f)
	{
		if(e<4)
		{
			fgets(path,sizeof(path),gg);
		}
		else
		{
			fscanf(gg,"%d%s%s%s%s%s",&elector[h].serialnumber,elector[h].firstname,elector[h].lastname,elector[h].date_of_birth,elector[h].address,elector[h].password);
			if(serialnumber==elector[h].serialnumber && strcmp(password,elector[h].password)==0)
			{
			    printf("\n\nUnique Identification Number:\t\t\t%d\n",elector[h].serialnumber);
			    printf("Voter/Elector Full Name\t%11s %-15s\n",elector[h].firstname,elector[h].lastname);
			    printf("Voter/Elector D.O.B\t%s\n",elector[h].date_of_birth);
			    printf("Voter/Elector Address\t\t%s\n",elector[h].address);
			    y=y+1;
			    break;
			}
			h++;
		}
		e++;
	}
	fclose(gg);
	if(y!=1)
	{
		printf("\nCould not find Voter!\n");
	}
    getch();
}
void give_vote()
{
	system("CLS");
	int serialn,serialnumber,e=1,ik,cl=0,d=1,f=0,h=0,aa=0,xx=0,ver;
	char password[25],path[200];
	FILE *gg,*gu,*gd,*cup;
	printf("Input unique identification number\t");
	scanf("%d",&serialn);
	printf("Enter your password:\t");
	scanf("%s",password);
	gg=fopen("voterlist.txt","r");
	while(fgets(path,sizeof(path),gg))
	{
		f++;
	}
	fclose(gg);
	gg=fopen("voterlist.txt","r");
	gu=fopen("temp.txt","w");
	while(e<=f)
	{
		if(e<4)
		{
			fgets(path,sizeof(path),gg);
			fprintf(gu,"%s",path);
		}
		else
		{
			fscanf(gg,"%d%s%s%s%s%s",&elector[h].serialnumber,elector[h].firstname,elector[h].lastname,elector[h].date_of_birth,elector[h].address,elector[h].password);
			if(serialn==elector[h].serialnumber && strcmp(password,elector[h].password)==0)
			{
				system("CLS");
				printf("You can cast vote to these candidates:\n\n");
				gd=fopen("candidatelist.txt","r");
				while(fgets(path,sizeof(path),gd))
				{
					cl++;
				}
				fclose(gd);
				gd=fopen("candidatelist.txt","r");
				while(d<=cl)
				{
					if(d<5)
					{
						fgets(path,sizeof(path),gd);
						printf("%s",path);
					}
					else
					{
						fscanf(gd,"%d%s%s%s",&participant[aa].serialnumber,participant[aa].fullname,participant[aa].nameofparty,participant[aa].campaigning);
						ver=strcmp(elector[h].address,participant[aa].campaigning);
						if(ver==0)
						{
							printf("%-6d%-16s%-16s%-16s\n",participant[aa].serialnumber,participant[aa].fullname,participant[aa].nameofparty,participant[aa].campaigning);
						}
						aa++;
					}
					d++;
				}
				fclose(gd);
				printf("\n\nInput the Serial Number for the Candidate to Cast Vote to!\t");
				scanf("%d",&serialnumber);
				cup=fopen("votecount.txt","r");
				if(cup==NULL)
				{
				fclose(cup);
				cup=fopen("votecount.txt","w");
				fprintf(cup,"VOTING DETAILS:\n");
				fprintf(cup," -------------------------- --------------- ---------- ---------------\n");
				fprintf(cup,"|%10s %-15s|%-15s|%-10s|%-15s|\n","Voter","name","Cadidate voted","Party","Candidacy From");
				fprintf(cup," -------------------------- --------------- ---------- ---------------\n");
				fclose(cup);
				goto continuehere;
				}
			    fclose(cup);
				continuehere:
				cup=fopen("votecount.txt","a");
				for(ik=0;ik<=aa;ik++)
				{
					if(participant[ik].serialnumber==serialnumber)
					{
						fprintf(cup,"%13s %-16s%-17s%-12s%-17s\n",elector[h].firstname,elector[h].lastname,participant[ik].fullname,participant[ik].nameofparty,participant[ik].campaigning);
					}
				}
				fclose(cup);
				xx=xx+1;
			}
			else
			{
			    fprintf(gu,"%13d%11s %-16s%-16s%-16s%-12s\n",elector[h].serialnumber,elector[h].firstname,elector[h].lastname,elector[h].date_of_birth,elector[h].address,elector[h].password);
			}
			h++;
		}
		e++;
	}
	fclose(gg);
	fclose(gu);
	if(xx==1)
	{
        printf("Your Vote has been casted!\n\n");
        printf("Since you can vote only once per electiion,\nthanks for voting.\nThank you for participating in the election!");
	}
	else
	{
		printf("\nCould not find Voter. Enter correct unique identification number AND/OR Password!");
	}
	remove("voterlist.txt");
	rename("temp.txt","voterlist.txt");
	getch();
}
void outcome()
{
	system("CLS");
	int ik,jk,d=0,aa=0,cl=1,numl,f,h,winnie;
	char path[150],horizontal[99],winner[15];
	FILE *gd,*cup;
	gd=fopen("candidatelist.txt","r");
	while(fgets(path,sizeof(path),gd))
	{
	    d++;
	}
	fclose(gd);
	d=d-5;      
	int countofvote[d];
	d=d+5;
	gd=fopen("candidatelist.txt","r");
	while(cl<=d)
	{
		if(cl<5)
		{
			fgets(path,sizeof(path),gd);
		}
		else
		{
			countofvote[aa]=0;
			fscanf(gd,"%d%s%s%s",&participant[aa].serialnumber,participant[aa].fullname,participant[aa].nameofparty,participant[aa].campaigning);
			cup=fopen("votecount.txt","r");
			numl=0;
	        while(fgets(horizontal,sizeof(horizontal),cup))
	        {
	            numl++;	
	        }
	        fclose(cup);
			cup=fopen("votecount.txt","r");
			f=1;
			h=0;
			while(f<=numl)
			{
				if(f<5)
				{
					fgets(horizontal,sizeof(horizontal),cup);
				}
				else
				{
				fscanf(cup,"%s%s%s%s%s",calculate[h].firstnameofvoter,calculate[h].lastnameofvoter,calculate[h].candidate,calculate[h].nameofparty,calculate[h].campaigning);
					if(strcmp(participant[aa].fullname,calculate[h].candidate)==0 && strcmp(participant[aa].campaigning,calculate[h].campaigning)==0)
					{
						countofvote[aa]=countofvote[aa]+1;
					}
					h++;
				}
				f++;
			}
			fclose(cup);
			aa++;
		}
		cl++;
	}
	fclose(gd);
	printf("The outcome of the elections are:\n\n");
	printf(" ---------------- ---------------- \n");
	printf("|%-16s|%-16s|\n","The Candidate","Number of Votes");
	printf(" ---------------- ---------------- \n");
	for(ik=0;ik<aa;ik++)
	{
			printf("|%-16s|%-16d|\n",participant[ik].fullname,countofvote[ik]);
	}
	printf(" ---------------- ---------------- \n\n");
	for(ik=0;ik<aa;ik++)
	{
		for(jk=ik+1;jk<aa;jk++)
		{
		if(countofvote[ik]<countofvote[jk])
		{
			winnie=countofvote[ik];
			countofvote[ik]=countofvote[jk];
			countofvote[jk]=winnie;
			sprintf(winner,"%s",participant[ik].fullname);
			sprintf(participant[ik].fullname,"%s",participant[jk].fullname);
			sprintf(participant[jk].fullname,"%s",winner);
		}
	    }
	}
	winnie=countofvote[0];
	sprintf(winner,"%s",participant[0].fullname);
	printf("\n\n %s is the leading candidate in the election with %d number of votes!",winner,winnie);
	getch();
}
